@echo off
chcp 65001 >nul
where node >nul 2>&1
if errorlevel 1 (
  echo Cai Node.js 24, sau do mo lai Start-Cpp-Runner.cmd.
  pause
  exit /b 1
)
node "%~dp0runner.cjs"
if errorlevel 1 pause
