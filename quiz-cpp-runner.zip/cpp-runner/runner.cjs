const { createServer } = require('node:http');
const { randomBytes, timingSafeEqual } = require('node:crypto');
const { spawn } = require('node:child_process');
const { existsSync, readFileSync } = require('node:fs');
const { mkdtemp, realpath, rm, writeFile } = require('node:fs/promises');
const { dirname, isAbsolute, join } = require('node:path');
const { tmpdir } = require('node:os');
const { isCompleteProgram } = require('../quiz-cpp.js');

const port = 43190;
const origins = new Set(['https://whoyouknowswho.github.io', 'http://127.0.0.1:3000', 'http://localhost:3000']);
const maxBodyBytes = 96 * 1024;
const maxCodeBytes = 64 * 1024;
const maxInputBytes = 8 * 1024;
const maxOutputBytes = 48 * 1024;
const jobTimeout = 0xe7f10001;
const jobFailure = 0xe7f10002;

function json(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}

async function readRequest(req) {
  if (Number(req.headers['content-length']) > maxBodyBytes) return null;
  const parts = [];
  let size = 0;
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > maxBodyBytes) return null;
    parts.push(chunk);
  }
  return JSON.parse(Buffer.concat(parts).toString('utf8'));
}

function createRunnerServer({ token, run, allowedOrigins = origins }) {
  const secret = Buffer.from(token);
  const panel = readFileSync(join(__dirname, 'panel.html'), 'utf8');
  let busy = false;
  const server = createServer({ requestTimeout: 10000, headersTimeout: 5000 }, async (req, res) => {
    const localHost = '127.0.0.1:' + server.address()?.port;
    if (req.headers.host !== localHost) return json(res, 403, { error: 'Địa chỉ trình chạy không hợp lệ.' });
    if (req.method === 'GET' && /^\/panel(?:\?|$)/.test(req.url)) {
      const nonce = randomBytes(18).toString('base64');
      const parents = [...allowedOrigins];
      const config = JSON.stringify({ parents, token }).replace(/</g, '\\u003c');
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'Content-Security-Policy': "default-src 'none'; script-src 'nonce-" + nonce + "'; style-src 'nonce-" + nonce
          + "'; connect-src 'self'; frame-ancestors " + parents.join(' ') + "; base-uri 'none'; form-action 'none'"
      });
      return res.end(panel.replaceAll('__QUIZ_NONCE__', nonce).replace('__QUIZ_CONFIG__', () => config));
    }
    if (req.headers.origin !== 'http://' + localHost) return json(res, 403, { error: 'Chỉ bảng C++ Runner trên máy này mới được gửi lệnh chạy.' });
    if (req.url !== '/run') return json(res, 404, { error: 'Không tìm thấy đường dẫn.' });
    if (req.method !== 'POST') return json(res, 405, { error: 'Chỉ nhận yêu cầu chạy từ nút Chạy C++.' });
    const key = Buffer.from(req.headers['x-quiz-runner-key'] || '');
    if (key.length !== secret.length || !timingSafeEqual(key, secret)) {
      return json(res, 403, { error: 'Phiên C++ Runner đã đổi. Hãy đóng bảng chạy rồi mở lại.' });
    }
    if (req.headers['content-type'] !== 'application/json') return json(res, 415, { error: 'Định dạng yêu cầu không hợp lệ.' });
    let payload;
    try {
      payload = await readRequest(req);
    } catch {
      return json(res, 400, { error: 'Không đọc được mã C++.' });
    }
    if (!payload) {
      req.resume();
      return json(res, 413, { error: 'Mã C++ hoặc dữ liệu nhập quá dài.' });
    }
    const { code, input = '' } = payload;
    if (typeof code !== 'string' || typeof input !== 'string'
      || Buffer.byteLength(code) > maxCodeBytes || Buffer.byteLength(input) > maxInputBytes || !isCompleteProgram(code)) {
      return json(res, 400, { error: 'Cần một chương trình có hàm main hoàn chỉnh và dữ liệu nhập trong giới hạn.' });
    }
    if (busy) return json(res, 409, { error: 'Một chương trình đang chạy. Hãy chờ kết quả rồi thử lại.' });
    busy = true;
    try {
      json(res, 200, await run(code, input));
    } catch (error) {
      console.error(error.message);
      json(res, 500, { error: 'Trình chạy gặp lỗi trên máy. Xem cửa sổ C++ Runner để biết chi tiết.' });
    } finally {
      busy = false;
    }
  });
  return server;
}

function runProcess(file, args, { cwd, env, input = '', timeout = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(file, args, { cwd, env, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    const stdout = [];
    const stderr = [];
    let remaining = maxOutputBytes;
    let truncated = false;
    let timedOut = false;
    const collect = parts => chunk => {
      const bytes = Math.min(chunk.length, remaining);
      if (bytes) parts.push(chunk.subarray(0, bytes));
      remaining -= bytes;
      truncated ||= bytes < chunk.length;
    };
    child.stdout.on('data', collect(stdout));
    child.stderr.on('data', collect(stderr));
    child.stdin.on('error', () => {});
    child.stdin.end(input, 'utf8');
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, timeout);
    child.once('error', error => {
      clearTimeout(timer);
      reject(error);
    });
    child.once('close', (exitCode, signal) => {
      clearTimeout(timer);
      resolve({
        exitCode: exitCode === null ? null : exitCode >>> 0,
        timedOut,
        signal,
        truncated,
        stdout: Buffer.concat(stdout).toString('utf8'),
        stderr: Buffer.concat(stderr).toString('utf8')
      });
    });
  });
}

async function findCompiler() {
  const configured = process.env.QUIZ_TDM_GXX;
  const candidates = configured ? [configured] : [
    join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Embarcadero', 'Dev-Cpp', 'TDM-GCC-64', 'bin', 'g++.exe'),
    join(process.env.ProgramFiles || 'C:\\Program Files', 'TDM-GCC-64', 'bin', 'g++.exe'),
    'C:\\TDM-GCC-64\\bin\\g++.exe'
  ];
  for (const file of candidates) {
    if (!isAbsolute(file) || !existsSync(file)) continue;
    const version = await runProcess(file, ['--version'], { timeout: 3000 });
    const target = await runProcess(file, ['-dumpmachine'], { timeout: 3000 });
    if (version.exitCode === 0 && /tdm64[^\r\n]*\b9\.2\.0\b/i.test(version.stdout)
      && target.exitCode === 0 && target.stdout.trim() === 'x86_64-w64-mingw32') return file;
  }
  throw new Error('Không tìm thấy TDM-GCC 9.2.0 64-bit. Cài đúng bản hoặc đặt QUIZ_TDM_GXX tới g++.exe của bản đó.');
}

async function removeChildFolder(folder, parent) {
  if (dirname(await realpath(folder)) !== parent) throw new Error('Không thể xác nhận thư mục tạm của trình chạy.');
  await rm(folder, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
}

async function createCppRunner(compiler, directory) {
  const workspace = await realpath(directory);
  const job = join(workspace, 'quiz-job.exe');
  const bootstrap = await runProcess(compiler, [
    '-m64', '-std=gnu++14', '-municode', '-static', join(__dirname, 'job.cpp'),
    '-o', job, '-ladvapi32'
  ], { cwd: workspace, timeout: 25000 });
  if (bootstrap.exitCode !== 0) throw new Error('Không khởi tạo được môi trường chạy C++.\n' + bootstrap.stderr);

  return async (code, input) => {
    const cwd = await mkdtemp(join(workspace, 'job-'));
    try {
      await writeFile(join(cwd, 'main.cpp'), code, 'utf8');
      const windows = process.env.SystemRoot || 'C:\\Windows';
      const env = {
        SystemRoot: windows, WINDIR: windows,
        Path: dirname(compiler) + ';' + join(windows, 'System32'),
        TEMP: cwd, TMP: cwd
      };
      const invoke = async (phase, executable, args, duration, count, stdin) => {
        const result = await runProcess(job, [cwd, String(duration), String(count), executable, ...args],
          { cwd, env, input: stdin, timeout: duration + 7000 });
        if (result.exitCode === jobFailure) throw new Error(result.stderr || 'Windows không mở được chương trình.');
        const timedOut = result.timedOut || result.exitCode === jobTimeout;
        return { phase, ...result, timedOut, exitCode: timedOut ? null : result.exitCode };
      };
      const executable = join(cwd, 'main.exe');
      const compiled = await invoke('compile', compiler,
        ['-m64', '-std=gnu++14', '-O0', '-fdiagnostics-color=never', 'main.cpp', '-o', 'main.exe'], 15000, 8, '');
      if (compiled.exitCode !== 0) return compiled;
      return await invoke('run', executable, [], 3000, 1, input);
    } finally {
      await removeChildFolder(cwd, workspace);
    }
  };
}

async function start() {
  if (process.platform !== 'win32') throw new Error('C++ Runner dùng trình biên dịch TDM-GCC trên Windows.');
  const compiler = await findCompiler();
  const temp = await realpath(tmpdir());
  const workspace = await mkdtemp(join(temp, 'quizscanner-cpp-'));
  const cleanup = () => removeChildFolder(workspace, temp);
  try {
    const run = await createCppRunner(compiler, workspace);
    const token = randomBytes(18).toString('hex');
    const server = createRunnerServer({ token, run });
    await new Promise((resolve, reject) => server.once('error', reject).listen(port, '127.0.0.1', resolve));
    console.log('QuizScanner C++ Runner | TDM-GCC 9.2.0 64-bit');
    console.log('Đã sẵn sàng. Mở bảng Chạy C++ trên QuizScanner và giữ cửa sổ này mở.');
    const stop = () => server.close(() => cleanup().catch(error => console.error(error.message)));
    process.once('SIGINT', stop);
    process.once('SIGTERM', stop);
  } catch (error) {
    await cleanup();
    throw error;
  }
}

if (require.main === module) {
  start().catch(error => {
    console.error(error.message);
    process.exitCode = 1;
  });
}

module.exports = { createRunnerServer, createCppRunner, findCompiler };
