#define _WIN32_WINNT 0x0602
#include <windows.h>

#include <cstdio>
#include <memory>
#include <string>
#include <vector>

constexpr DWORD timeoutExit = 0xe7f10001;
constexpr DWORD launchErrorExit = 0xe7f10002;
using Handle = std::unique_ptr<void, decltype(&CloseHandle)>;

struct Attributes {
    std::vector<unsigned char> memory;
    LPPROC_THREAD_ATTRIBUTE_LIST list = nullptr;
    bool initialize() {
        SIZE_T bytes = 0;
        InitializeProcThreadAttributeList(nullptr, 1, 0, &bytes);
        memory.resize(bytes);
        auto candidate = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(memory.data());
        if (!InitializeProcThreadAttributeList(candidate, 1, 0, &bytes)) return false;
        list = candidate;
        return true;
    }
    ~Attributes() {
        if (list) DeleteProcThreadAttributeList(list);
    }
};

std::wstring quote(const std::wstring& value) {
    std::wstring out = L"\"";
    size_t backslashes = 0;
    for (wchar_t ch : value) {
        if (ch == L'\\') {
            backslashes++;
            continue;
        }
        out.append(backslashes * (ch == L'"' ? 2 : 1), L'\\');
        if (ch == L'"') out += L'\\';
        out += ch;
        backslashes = 0;
    }
    out.append(backslashes * 2, L'\\');
    return out + L'"';
}

DWORD fail(const char* step, DWORD error) {
    std::fprintf(stderr, "C++ Runner: %s (0x%08lX)\n", step, static_cast<unsigned long>(error));
    return launchErrorExit;
}

DWORD launch(int argc, wchar_t** argv) {
    if (argc < 5) return fail("missing launch arguments", ERROR_INVALID_PARAMETER);
    const DWORD timeout = std::wcstoul(argv[2], nullptr, 10);
    const DWORD processLimit = std::wcstoul(argv[3], nullptr, 10);
    if (!timeout || !processLimit) return fail("invalid job limits", ERROR_INVALID_PARAMETER);

    HANDLE rawToken = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &rawToken)) return fail("check Windows permissions", GetLastError());
    Handle token(rawToken, CloseHandle);
    TOKEN_ELEVATION elevation{};
    DWORD bytes = 0;
    if (!GetTokenInformation(token.get(), TokenElevation, &elevation, sizeof(elevation), &bytes)) {
        return fail("read Windows permissions", GetLastError());
    }
    if (elevation.TokenIsElevated) return fail("open the runner without administrator privileges", ERROR_ACCESS_DENIED);

    Handle job(CreateJobObjectW(nullptr, nullptr), CloseHandle);
    if (!job) return fail("create process job", GetLastError());
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        | JOB_OBJECT_LIMIT_ACTIVE_PROCESS | JOB_OBJECT_LIMIT_JOB_MEMORY;
    limits.BasicLimitInformation.ActiveProcessLimit = processLimit;
    limits.JobMemoryLimit = (processLimit == 1 ? 192 : 512) * 1024ull * 1024ull;
    if (!SetInformationJobObject(job.get(), JobObjectExtendedLimitInformation, &limits, sizeof(limits))) {
        return fail("limit process job", GetLastError());
    }

    const DWORD stdIds[] = { STD_INPUT_HANDLE, STD_OUTPUT_HANDLE, STD_ERROR_HANDLE };
    Handle handles[] = { Handle(nullptr, CloseHandle), Handle(nullptr, CloseHandle), Handle(nullptr, CloseHandle) };
    HANDLE inherited[3]{};
    for (size_t i = 0; i < 3; i++) {
        if (!DuplicateHandle(GetCurrentProcess(), GetStdHandle(stdIds[i]), GetCurrentProcess(),
            &inherited[i], 0, TRUE, DUPLICATE_SAME_ACCESS)) return fail("prepare standard streams", GetLastError());
        handles[i].reset(inherited[i]);
    }
    Attributes attributes;
    if (!attributes.initialize()
        || !UpdateProcThreadAttribute(attributes.list, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
            inherited, sizeof(inherited), nullptr, nullptr)) return fail("limit inherited handles", GetLastError());

    std::wstring arguments = quote(argv[4]);
    for (int i = 5; i < argc; i++) arguments += L" " + quote(argv[i]);
    STARTUPINFOEXW startup{};
    startup.StartupInfo.cb = sizeof(startup);
    startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    startup.StartupInfo.hStdInput = inherited[0];
    startup.StartupInfo.hStdOutput = inherited[1];
    startup.StartupInfo.hStdError = inherited[2];
    startup.lpAttributeList = attributes.list;
    PROCESS_INFORMATION process{};
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
    const DWORD flags = CREATE_SUSPENDED | CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT | BELOW_NORMAL_PRIORITY_CLASS;
    if (!CreateProcessW(argv[4], &arguments[0], nullptr, nullptr, TRUE, flags, nullptr, argv[1],
        &startup.StartupInfo, &process)) return fail("start process", GetLastError());

    Handle program(process.hProcess, CloseHandle);
    Handle thread(process.hThread, CloseHandle);
    if (!AssignProcessToJobObject(job.get(), program.get())) {
        const DWORD error = GetLastError();
        TerminateProcess(program.get(), launchErrorExit);
        WaitForSingleObject(program.get(), 1000);
        return fail("attach process to job", error);
    }
    if (ResumeThread(thread.get()) == static_cast<DWORD>(-1)) return fail("resume process", GetLastError());
    const DWORD wait = WaitForSingleObject(program.get(), timeout);
    if (wait == WAIT_TIMEOUT) {
        TerminateJobObject(job.get(), timeoutExit);
        WaitForSingleObject(program.get(), 1000);
        return timeoutExit;
    }
    if (wait != WAIT_OBJECT_0) return fail("wait for process", GetLastError());
    DWORD exitCode = 0;
    if (!GetExitCodeProcess(program.get(), &exitCode)) return fail("read exit status", GetLastError());
    return exitCode;
}

int wmain(int argc, wchar_t** argv) {
    return static_cast<int>(launch(argc, argv));
}
